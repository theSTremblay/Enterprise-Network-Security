<?php

# No protections, anything goes

?>
