<?php
print "Current Direct: ";

echo getcwd();

$current_path = getcwd();


print "Contents of Current Direct: ";

$output = shell_exec('ls -lart');
echo "<pre>$output</pre>";

$files = scandir($current_path);

print "\n";

$files = array_diff(scandir($current_path), array('.', '..'));

echo $files;


# Time for the getting the root
print "\n" . "Root Direct: ";
$path="/";
chdir($path);
echo getcwd();
$output = shell_exec('ls /');
#$output = shell_exec('ls -lart');
echo "<pre>$output</pre>";
#$output2 = shell_exec('cd /;ls -lart');


# Process count
static $ver, $runs = 0;
  
// check if php version supports clearstatcache params, but only check once
if ( is_null( $ver ) )
    $ver = version_compare( PHP_VERSION, '5.3.0', '>=' );

  // Only call clearstatcache() if function called more than once */
  if ( $runs++ > 0 ) { // checks if $runs > 0, then increments $runs by one.
    
    // if php version is >= 5.3.0
    if ( $ver ) {
      clearstatcache( true, '/proc' );
    } else {
      // if php version is < 5.3.0
      clearstatcache();
    }
  }
  
$stat = stat( '/proc' );


echo '<pre>'; print_r($stat); echo '</pre>';

echo 'Number of Processes: ';
echo $stat['nlink'];

?>
