/** askapache_get_process_count()
 * Returns the number of running processes
 *
 * @version 1.4
 *
 * @return int
 */
function askapache_get_process_count() {
  static $ver, $runs = 0;
  
  // check if php version supports clearstatcache params, but only check once
  if ( is_null( $ver ) )
    $ver = version_compare( PHP_VERSION, '5.3.0', '>=' );

  // Only call clearstatcache() if function called more than once */
  if ( $runs++ > 0 ) { // checks if $runs > 0, then increments $runs by one.
    
    // if php version is >= 5.3.0
    if ( $ver ) {
      clearstatcache( true, '/proc' );
    } else {
      // if php version is < 5.3.0
      clearstatcache();
    }
  }
  
  $stat = stat( '/proc' );

  // if stat succeeds and nlink value is present return it, otherwise return 0
  return ( ( false !== $stat && isset( $stat[3] ) ) ? $stat[3] : 0 );
}
