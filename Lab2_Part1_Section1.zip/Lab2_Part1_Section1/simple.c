#include <stdio.h>

main() {
   FILE *fp;

   fp = fopen("/home/class/labs-sec/lab2/simple_example/data/simple.txt", "w+");
   fprintf(fp, "This is testing for fprintf...\n");
   fputs("Hello World!\n", fp);
   fclose(fp);

// The part that does the reading from data secret.txt
int c;
FILE *file;
file = fopen("/home/class/labs-sec/lab2/simple_example/data/secret.txt", "r");
if (file) {
    while ((c = getc(file)) != EOF)
        putchar(c);
    fclose(file);
}
}
